﻿#include "GamePCH.h"
#include "$safeitemname$.h"

namespace game
{
    void $safeitemname$::OnGui()
    {
    }

    void $safeitemname$::Save(engine::json& j) const
    {
        j["Type"] = GetType();
    }

    void $safeitemname$::Load(const engine::json& j)
    {
    }

    std::string $safeitemname$::GetType() const
    {
        return "$safeitemname$";
    }
}